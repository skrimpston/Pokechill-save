let saved = {}


saved.preview1 = {}

saved.preview1.slot1 = { } 
saved.preview1.slot2 = { } 
saved.preview1.slot3 = { } 
saved.preview1.slot4 = { } 
saved.preview1.slot5 = { } 
saved.preview1.slot6 = { } 

saved.preview1.slot1.item = undefined
saved.preview1.slot2.item = undefined
saved.preview1.slot3.item = undefined
saved.preview1.slot4.item = undefined
saved.preview1.slot5.item = undefined
saved.preview1.slot6.item = undefined

saved.preview1.slot1.pkmn = undefined
saved.preview1.slot2.pkmn = undefined
saved.preview1.slot3.pkmn = undefined
saved.preview1.slot4.pkmn = undefined
saved.preview1.slot5.pkmn = undefined
saved.preview1.slot6.pkmn = undefined

saved.preview2 = {}

saved.preview2.slot1 = { } 
saved.preview2.slot2 = { } 
saved.preview2.slot3 = { } 
saved.preview2.slot4 = { } 
saved.preview2.slot5 = { } 
saved.preview2.slot6 = { } 

saved.preview2.slot1.item = undefined
saved.preview2.slot2.item = undefined
saved.preview2.slot3.item = undefined
saved.preview2.slot4.item = undefined
saved.preview2.slot5.item = undefined
saved.preview2.slot6.item = undefined

saved.preview2.slot1.pkmn = undefined
saved.preview2.slot2.pkmn = undefined
saved.preview2.slot3.pkmn = undefined
saved.preview2.slot4.pkmn = undefined
saved.preview2.slot5.pkmn = undefined
saved.preview2.slot6.pkmn = undefined

saved.preview3 = {}

saved.preview3.slot1 = { } 
saved.preview3.slot2 = { } 
saved.preview3.slot3 = { } 
saved.preview3.slot4 = { } 
saved.preview3.slot5 = { } 
saved.preview3.slot6 = { } 

saved.preview3.slot1.item = undefined
saved.preview3.slot2.item = undefined
saved.preview3.slot3.item = undefined
saved.preview3.slot4.item = undefined
saved.preview3.slot5.item = undefined
saved.preview3.slot6.item = undefined

saved.preview3.slot1.pkmn = undefined
saved.preview3.slot2.pkmn = undefined
saved.preview3.slot3.pkmn = undefined
saved.preview3.slot4.pkmn = undefined
saved.preview3.slot5.pkmn = undefined
saved.preview3.slot6.pkmn = undefined

saved.preview4 = {}

saved.preview4.slot1 = { } 
saved.preview4.slot2 = { } 
saved.preview4.slot3 = { } 
saved.preview4.slot4 = { } 
saved.preview4.slot5 = { } 
saved.preview4.slot6 = { } 

saved.preview4.slot1.item = undefined
saved.preview4.slot2.item = undefined
saved.preview4.slot3.item = undefined
saved.preview4.slot4.item = undefined
saved.preview4.slot5.item = undefined
saved.preview4.slot6.item = undefined

saved.preview4.slot1.pkmn = undefined
saved.preview4.slot2.pkmn = undefined
saved.preview4.slot3.pkmn = undefined
saved.preview4.slot4.pkmn = undefined
saved.preview4.slot5.pkmn = undefined
saved.preview4.slot6.pkmn = undefined

saved.preview5 = {}

saved.preview5.slot1 = { } 
saved.preview5.slot2 = { } 
saved.preview5.slot3 = { } 
saved.preview5.slot4 = { } 
saved.preview5.slot5 = { } 
saved.preview5.slot6 = { } 

saved.preview5.slot1.item = undefined
saved.preview5.slot2.item = undefined
saved.preview5.slot3.item = undefined
saved.preview5.slot4.item = undefined
saved.preview5.slot5.item = undefined
saved.preview5.slot6.item = undefined

saved.preview5.slot1.pkmn = undefined
saved.preview5.slot2.pkmn = undefined
saved.preview5.slot3.pkmn = undefined
saved.preview5.slot4.pkmn = undefined
saved.preview5.slot5.pkmn = undefined
saved.preview5.slot6.pkmn = undefined

saved.preview6 = {}

saved.preview6.slot1 = { } 
saved.preview6.slot2 = { } 
saved.preview6.slot3 = { } 
saved.preview6.slot4 = { } 
saved.preview6.slot5 = { } 
saved.preview6.slot6 = { } 

saved.preview6.slot1.item = undefined
saved.preview6.slot2.item = undefined
saved.preview6.slot3.item = undefined
saved.preview6.slot4.item = undefined
saved.preview6.slot5.item = undefined
saved.preview6.slot6.item = undefined

saved.preview6.slot1.pkmn = undefined
saved.preview6.slot2.pkmn = undefined
saved.preview6.slot3.pkmn = undefined
saved.preview6.slot4.pkmn = undefined
saved.preview6.slot5.pkmn = undefined
saved.preview6.slot6.pkmn = undefined